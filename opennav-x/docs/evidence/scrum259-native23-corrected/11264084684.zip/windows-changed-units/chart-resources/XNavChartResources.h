#pragma once
#include <cstdint>
namespace opennav::chart_style::generated {
struct Resource { const char *name; const char *sha256; std::uint64_t bytes; };
inline constexpr Resource resources[] = {
  {"chartsymbols.xml", "d4e9274e379b30368ac355f90e5c9786e86f7c979fb82c524ebddf366dc6fba9", 2232050},
  {"S52RAZDS.RLE", "560e1a1df493d7ae4c8506da814ad936adb13ef93c6f1e2abc93f2819860ff26", 1305627},
  {"rastersymbols-day.png", "a737bdb7d372077c2bfe806c5f020f45b4517029c0b43913084720664c520ea3", 197801},
  {"rastersymbols-dusk.png", "201f0663bd786d5e1d8ba09d8d43b106df164d5a282f60860258d226adadb6c9", 172357},
  {"rastersymbols-dark.png", "9c91273e3dbe9563d79b2d2b0a757bb83207aa0db9183e8aecc1112070ead724", 167654},
};
struct Background { std::uint32_t land, water; };
inline constexpr Background backgrounds[] = {
  {0xeeeee2, 0xd5e5e5},
  {0x4e615d, 0x344f59},
  {0x1d2925, 0x0e171c},
};
} // namespace opennav::chart_style::generated
