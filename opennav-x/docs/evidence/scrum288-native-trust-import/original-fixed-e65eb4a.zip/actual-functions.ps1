function Digest([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }

function Write-TrustProgress([string]$Stage,[string]$Name,[string]$State,[string]$Detail='') {
  $Event=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');stage=$Stage;name=$Name;state=$State;detail=$Detail}
  $Event|ConvertTo-Json -Compress|Add-Content -LiteralPath (Join-Path $Evidence 'progress.jsonl') -Encoding utf8
  Write-Host "$($Event.utc) $Stage/$Name $State $Detail"
}

function Invoke-BoundedProbe([string]$Name,[string]$Program,[string[]]$Arguments,[ValidateRange(1,30)][int]$TimeoutSeconds=30) {
  $Start=[Diagnostics.ProcessStartInfo]::new($Program)
  $Start.UseShellExecute=$false;$Start.RedirectStandardOutput=$true;$Start.RedirectStandardError=$true
  $Start.WorkingDirectory=(Get-Location).Path
  foreach($Argument in $Arguments){$Start.ArgumentList.Add($Argument)}
  $Process=$null;$Watch=[Diagnostics.Stopwatch]::StartNew()
  Write-TrustProgress 'process' $Name 'before'
  try {
    $Process=[Diagnostics.Process]::Start($Start)
    $Stdout=$Process.StandardOutput.ReadToEndAsync();$Stderr=$Process.StandardError.ReadToEndAsync()
    $TimedOut=-not $Process.WaitForExit($TimeoutSeconds * 1000)
    if($TimedOut){
      Write-TrustProgress 'process' $Name 'timeout' "Exceeded $TimeoutSeconds seconds; terminating owned process tree"
      if(-not $Process.HasExited){$Process.Kill($true)}
      if(-not $Process.WaitForExit(5000)){throw "$Name process tree did not terminate"}
    }
    if(-not $Stdout.Wait(5000) -or -not $Stderr.Wait(5000)){throw "$Name output pipes did not close"}
    $Stdout.Result|Set-Content -LiteralPath (Join-Path $Evidence "$Name.stdout.txt") -Encoding utf8
    $Stderr.Result|Set-Content -LiteralPath (Join-Path $Evidence "$Name.stderr.txt") -Encoding utf8
    $Record=[ordered]@{processId=$Process.Id;exitCode=$Process.ExitCode;timedOut=$TimedOut;timeoutSeconds=$TimeoutSeconds;elapsedSeconds=$Watch.Elapsed.TotalSeconds}
    $Record|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Evidence "$Name.process.json") -Encoding utf8
    if($TimedOut){throw "$Name exceeded the $TimeoutSeconds-second native probe limit"}
    Write-TrustProgress 'process' $Name 'after' "exit=$($Process.ExitCode)"
    return @{output=($Stdout.Result+"`n"+$Stderr.Result);exitCode=$Process.ExitCode}
  } catch {
    Write-TrustProgress 'process' $Name 'failure' $_.Exception.Message
    throw
  } finally {
    if($Process){
      try {
        if(-not $Process.HasExited){$Process.Kill($true)}
        if(-not $Process.WaitForExit(5000)){throw "$Name owned process remains after cleanup"}
      } finally { $Process.Dispose() }
    }
  }
}

function Import-OwnedTrust([string]$Certificate) {
  Write-TrustProgress 'trust-import' 'LocalMachine-Root' 'before'
  try {
  $Candidate = [Security.Cryptography.X509Certificates.X509Certificate2]::new($Certificate)
  $CandidateThumbprint = $Candidate.Thumbprint
  $Path = "Cert:\LocalMachine\Root\$CandidateThumbprint"
  if (Test-Path -LiteralPath $Path) { throw 'Generated CA thumbprint unexpectedly already exists in LocalMachine Root' }
  # From this point onward cleanup owns this exact, previously absent identity,
  # including when the bounded import fails after a partial import.
  $script:TrustedThumbprint = $CandidateThumbprint
  # CurrentUser root imports display a modal Security Warning on hosted Windows.
  # Use the disposable runner's machine store; never alter user/machine policy.
  $Import = Invoke-BoundedProbe 'owned-ca-import' (Join-Path $env:SystemRoot 'System32/certutil.exe') @('-f','-addstore','Root',$Certificate)
  if ($Import.exitCode -ne 0 -or -not (Test-Path -LiteralPath $Path)) {
    throw 'Owned CA import failed or its exact thumbprint is absent'
  }
  $Imported = Get-Item -LiteralPath $Path
  if ($Imported.Thumbprint -cne $script:TrustedThumbprint -or [Convert]::ToBase64String($Imported.RawData) -cne [Convert]::ToBase64String($Candidate.RawData)) {
    throw 'Owned CA import differs from the exact generated certificate'
  }
  Write-TrustProgress 'trust-import' 'LocalMachine-Root' 'after'
  } catch { Write-TrustProgress 'trust-import' 'LocalMachine-Root' 'failure' $_.Exception.Message; throw }
}

function Remove-OwnedTrust {
  if (-not $script:TrustedThumbprint) { return }
  $Path = "Cert:\LocalMachine\Root\$($script:TrustedThumbprint)"
  if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force }
  if (Test-Path -LiteralPath $Path) { throw "Failed to remove owned LocalMachine Root certificate $($script:TrustedThumbprint)" }
}
