param([string]$Certificate,[string]$Mode,[string]$Events)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
function Stage([string]$Name) {
  @{utc=[DateTime]::UtcNow.ToString('o');stage=$Name;process_id=$PID} | ConvertTo-Json -Compress | Add-Content -LiteralPath $Events -Encoding utf8
}
function Import-OwnedTrust([string]$Certificate) {
  $Candidate = [Security.Cryptography.X509Certificates.X509Certificate2]::new($Certificate)
  $CandidateThumbprint = $Candidate.Thumbprint
  $Path = "Cert:\CurrentUser\Root\$CandidateThumbprint"
  if (Test-Path -LiteralPath $Path) { throw 'Generated CA thumbprint unexpectedly already exists in CurrentUser Root' }
  # From this point onward cleanup owns this exact, previously absent identity,
  # including when Import-Certificate throws after a partial import.
  $script:TrustedThumbprint = $CandidateThumbprint
  Stage 'before-Import-Certificate'
  $Imported = Import-Certificate -FilePath $Certificate -CertStoreLocation 'Cert:\CurrentUser\Root'
  Stage 'after-Import-Certificate'
  if ($Imported.Thumbprint -cne $script:TrustedThumbprint -or -not (Test-Path -LiteralPath $Path)) {
    throw 'Owned CA import could not be verified by exact thumbprint'
  }
}
Stage 'child-start'
if ($Mode -ceq 'original') {
  Import-OwnedTrust $Certificate
} elseif ($Mode -ceq 'certutil-user-force') {
  Stage 'before-certutil-user-force'
  & "$env:SystemRoot/System32/certutil.exe" -user -f -addstore Root $Certificate
  if ($LASTEXITCODE -ne 0) { throw "certutil failed: $LASTEXITCODE" }
  Stage 'after-certutil-user-force'
} else { throw 'Unknown diagnostic mode' }
Stage 'child-success'
