#pragma once
#include <cstdint>
namespace opennav::chart_style::generated {
struct Resource { const char *name; const char *sha256; std::uint64_t bytes; };
inline constexpr Resource resources[] = {
  {"chartsymbols.xml", "beca42d4f1e1cbe5dd761d3e2182d5ebe935556a94674df5da47aaafe7fb0119", 2242082},
  {"S52RAZDS.RLE", "560e1a1df493d7ae4c8506da814ad936adb13ef93c6f1e2abc93f2819860ff26", 1305627},
  {"rastersymbols-day.png", "e71bb49aa0c4d18990ed3fef9362989df25a2efc49bc41ff5439bea993d6df06", 199796},
  {"rastersymbols-dusk.png", "8a1c1f1db4f2e9d10b1d67687ca96b7f5cbda9ed3e0acdb77162c5a231bb1308", 174185},
  {"rastersymbols-dark.png", "8606b8f2f7727c2b4f906d55bad92ee0a7331c3fdfce3276dc01eba4e5a0b5c7", 169565},
};
struct Background { std::uint32_t land, water; };
inline constexpr Background backgrounds[] = {
  {0xeeeee2, 0xd5e5e5},
  {0x4e615d, 0x344f59},
  {0x1d2925, 0x0e171c},
};
} // namespace opennav::chart_style::generated
