#pragma once
#include <cstdint>
namespace opennav::chart_style::generated {
struct Resource { const char *name; const char *sha256; std::uint64_t bytes; };
inline constexpr Resource resources[] = {
  {"chartsymbols.xml", "f4a20a46b0e5dbc9216f67386a1b0e6dd7c73e982b7b334b0ae795cd2c5f5334", 2245002},
  {"S52RAZDS.RLE", "560e1a1df493d7ae4c8506da814ad936adb13ef93c6f1e2abc93f2819860ff26", 1305627},
  {"rastersymbols-day.png", "852753fa6b8d32b23cfec81d060496c2602e8f1b590c73c7921e2041b4de745f", 200449},
  {"rastersymbols-dusk.png", "882b3486bcabd3a075ae567f42e284ff065e83ebfe5033bb6eb68f655d18202e", 174807},
  {"rastersymbols-dark.png", "ab539905f9059ec8398b5e466a71bf7268368d66776cd41ea13706b79047a4f5", 170162},
};
struct Background { std::uint32_t land, water; };
inline constexpr Background backgrounds[] = {
  {0xeeeee2, 0xd5e5e5},
  {0x4e615d, 0x344f59},
  {0x1d2925, 0x0e171c},
};
} // namespace opennav::chart_style::generated
